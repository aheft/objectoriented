package rogue;
import java.awt.Point;

/**
 * A basic Item class; basic functionality for both consumables and equipment
 */
public class Item  {



    //Constructors
    public Item() {
        
    }

    public Item(int id, String name, String type, Point xyLocation) {

    }
    
    // Getters and setters


    public int getId() {
        return 0;
       
    }


    public void setId(int id) {

    }


    public String getName() {
        return null;
    }


    public void setName(String name) {

    }


    public String getType() {
        return null;

    }


    public void setType(String type) {

    }
    

    public Character getDisplayCharacter() {
        return null;
        
    }


    public void setDisplayCharacter(Character newDisplayCharacter) {
        
    }


    public String getDescription() {
        return null;
     
    }


    public void setDescription(String newDescription) {
     
    }


    public Point getXyLocation() {
        return null;
     
    }

    
    public void setXyLocation(Point newXyLocation) {
        
    }


    public Room getCurrentRoom() {
        return null;
        
    }


    public void setCurrentRoom(Room newCurrentRoom) {
        
    }
}
