package rogue;

import java.util.ArrayList;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.awt.Point;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class Rogue{

    public void setPlayer(Player thePlayer){

    }


    public void setSymbols(String filename){

    }

    public ArrayList<Room> getRooms(){
        return null;

    }

    public ArrayList<Item> getItems(){
        return null;

    }
    public Player getPlayer(){
        return null;

    }

    public void createRooms(String filename){

    }
    public String displayAll(){
        //creates a string that displays all the rooms in the dungeon
        return null;
    }
}